/**
 * The GraphExperiment class and main program, where the performance of dijkstra is evaluted by finding the shortest path
 * @author CHNSAD004
 */
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Map;
import java.util.HashMap;
import java.util.NoSuchElementException;
import java.util.PriorityQueue;
import java.util.Scanner;
import java.util.StringTokenizer;


// GraphExperiment class: evaluate shortest paths using dijkstra's algorithm
//
// CONSTRUCTION: with no parameters.
//
// ******************PUBLIC OPERATIONS**********************
// void addEdge( String v, String w, double cvw )
//                              --> Add additional edge
// void printPath( String w )   --> Print path after alg is run
// void dijkstra( String s )    --> Single-source weighted
// ******************ERRORS*********************************
// Some error checking is performed to make sure graph is ok,
// and to make sure graph satisfies properties needed by each
// algorithm.  Exceptions are thrown if errors are detected.

public class GraphExperiment {
    // constants
    public static final double INFINITY = Double.MAX_VALUE;
    private Map<String,Vertex> vertexMap = new HashMap<String,Vertex>( );
    public static int opcount_v, opcount_pq, opcount_e, numEdges; // initialises the variables for tracking the number of edges, vertices and queues

    /**
     * Add a new edge to the graph.
     * @param sourceName the first node
     * @param destName the last node
     * @param cost cost between the two nodes
     */
    public void addEdge( String sourceName, String destName, double cost )
    {
        Vertex v = getVertex( sourceName );
        Vertex w = getVertex( destName );
        v.adj.add( new Edge( w, cost ) );
    }

    /**
     * Driver routine to handle unreachables and print total cost.
     * It calls recursive routine to print shortest path to
     * destNode after a shortest path algorithm has run.
     * @param destName the last node
     */
    public void printPath( String destName )
    {
        Vertex w = vertexMap.get( destName );
        if( w == null )
            throw new NoSuchElementException( "Destination vertex not found" );
        else if( w.dist == INFINITY )
            System.out.println( destName + " is unreachable" );
        else
        {
            System.out.print( "(Cost is: " + w.dist + ") " );
            printPath( w );
            System.out.println( );
        }
    }

    /**
     * If vertexName is not present, add it to vertexMap.
     * In either case, return the Vertex.
     * @param vertexName the name of the node
     * @return the name of the node
     */
    public Vertex getVertex( String vertexName )
    {
        Vertex v = vertexMap.get( vertexName );
        if( v == null )
        {
            v = new Vertex( vertexName );
            vertexMap.put( vertexName, v );
        }
        return v;
    }

    /**
     * Recursive routine to print shortest path to dest
     * after running shortest path algorithm. The path
     * is known to exist.
     * @param dest the end node
     */
    private void printPath( Vertex dest )
    {
        if( dest.prev != null )
        {
            printPath( dest.prev );
            System.out.print( " to " );
        }
        System.out.print( dest.name );
    }
    
    /**
     * Initializes the vertex output info prior to running
     * any shortest path algorithm.
     */
    private void clearAll( )
    {
        for( Vertex v : vertexMap.values( ) )
            v.reset( );
    }

    /**
     * Single-source weighted shortest-path algorithm. (Dijkstra) 
     * using priority queues based on the binary heap
     * @param startName the first node
     * @return the number of priority queues
     */
    public int dijkstra(String startName) {
        PriorityQueue<Path> pq = new PriorityQueue<Path>(); // starts a new priority queue

        Vertex start = vertexMap.get(startName);  // gets the first node
        // check that first node isnt empty
        if(start == null)
            throw new NoSuchElementException("Start vertex not found");

        clearAll(); // reset the counts
        opcount_pq = 0;
        pq.add(new Path(start, 0)); 
        start.dist = 0;
        
        int nodesSeen = 0;
        while(!pq.isEmpty() && nodesSeen < vertexMap.size()) {       
            Path vrec = pq.remove();
            Vertex v = vrec.dest;
            if(v.scratch != 0) { // already processed v
                continue;
            }
            // vertex is being processed
            opcount_v++;    // instrumentation
                
            v.scratch = 1;
            nodesSeen++;

            for(Edge e : v.adj) {
                Vertex w = e.dest;
                double cvw = e.cost;
                
                if(cvw < 0) {
                    throw new GraphException("Graph has negative edges");
                }
                //edges being processed
                opcount_e++;    // instrumentation
                 
                if(w.dist > v.dist + cvw) {
                    w.dist = v.dist +cvw;
                    w.prev = v;
                    pq.add(new Path(w, w.dist));
                    opcount_pq++;      // instrumentation   
                }
            }
        }
        return opcount_pq;
    }

    /**
     * Process a request; return false if end of file.
     * @param n the filename of the datafile being read
     * @param g the graph
     * @return false to signify the end of the file
     */
    public static boolean processRequest(String n, GraphExperiment g) {
        // uses a try catch to avoid Graph and IO exceptions which can break the code
        try {
        String fileN = n; // obtains filepath from the input
        String fNode = getFirstNode(fileN);  // gets the first node of the file
            try {
                g.dijkstra(fNode);    // finds shortest path to the last node
            }
            catch(GraphException e) {
                System.err.println(e); 
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * A main routine that:
     * 1. Reads 25 files containing the vertices and edges and cost;
     * 2. Runs Dijkstra's Algorithm to find the shortest path
     * The data file is a sequence of lines of the format
     *    source destination cost
     * 3, Prints out the values to the screen
     * 4. Writes the results to an output textfile called "GraphExperimentData.txt"
     * @param args starts the main method
     */
    public static void main(String [ ] args) {
        GraphExperiment g = new GraphExperiment();
        try {
            FileWriter w = new FileWriter("GraphExperimentData.txt"); // prepares the new file
            // interate through all 25 files
            for (int p = 1; p <= 25; p++) {
                String fileN = "graph" + p + ".txt";
                try (FileReader file = new FileReader(fileN)) {
                    Scanner gFile = new Scanner(file); // read file
                    // Read the edges and insert
                    String line;
                    while(gFile.hasNextLine()) {
                        line = gFile.nextLine();
                        StringTokenizer st = new StringTokenizer(line); // start new token with line

                        try {
                            // ensures all lines have 3 tokens to represent NodeXXX NodeXXX cost
                            if(st.countTokens() != 3) {
                                System.err.println("Skipping ill-formatted line " + line);
                                continue;
                            }
                            // separates each token into the correct order
                            String source  = st.nextToken();
                            String dest    = st.nextToken();
                            int    cost    = Integer.parseInt(st.nextToken());
                            g.addEdge(source, dest, cost);
                        }
                        catch( NumberFormatException e ) {
                            System.err.println("Skipping ill-formatted line " + line); 
                        }
                    }
                    gFile.close(); // close scanner
                }
                // count the number of edges of the graph
                int numE = numEdges(fileN);
                // write results to the output file in the form of vertices edges priority queues
                w.write(g.vertexMap.size() + " "+ numE + " " + opcount_pq + "\n");
                w.flush();
                // Report the values to the screen
                System.out.println("Experiment for " + fileN);
                System.out.println("Vertices: " + g.vertexMap.size());
                System.out.println("Edges: " + numE);
                System.out.println("Priority queues: " + opcount_pq);
                System.out.println("-------------------------------------------------");
                // continues the loop until all files are read
                while (processRequest(fileN, g)) {
                }
            // prod for next graph for new data file
            g = new GraphExperiment();
            }
            w.close(); // close filewriter
            // print out completed message
            System.out.println("Data written to GraphExperimentData.txt");
        }catch( IOException e )
           { System.err.println( e ); }
    }

    /**
     * Counts the number of edges in the graph
     * @param filePath selects the datafile to count edges in
     * @return number of edges in graph
     * @throws IOException 
     */
    public static int numEdges(String filePath) throws IOException {
        BufferedReader r = null;
        int e = 0;
        try {
            r = new BufferedReader(new FileReader(filePath));   // reads in the file
            while (r.readLine() != null) {
                e++;    // while the line is not empty add 1 to the edge count
            }
        } finally {
            if (r != null) {
                r.close();  // close the reader ending the count
            }
        }
        return e;
    }

    /**
     * Get the first node of the textfile graph
     * @param filePath selects the textfile graph to obtain the first node from
     * @return the first node
     * @throws IOException
     */
    public static String getFirstNode(String filePath) throws IOException {
        BufferedReader r = null;
        String first = null;
        try {
            r = new BufferedReader(new FileReader(filePath)); // reads the file
            first = r.readLine(); // reads the first line
            if (first != null) {
                StringTokenizer st = new StringTokenizer(first); // split line into 3 tokens
                String node = st.nextToken();
                // checks token is not empty
                if (node.length() > 0) {
                    first = node; // select the first token
                }
            }
        } finally {
            if (r != null) {
                r.close(); // close the reader
            }
        }
        return first;
    }
}
