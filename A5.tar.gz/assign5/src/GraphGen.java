import java.io.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.StringTokenizer;

/**
 *  The GraphGen class generates graphs according to the specification in the assignment instructions
 * @author CHNSAD004
 */ 
public class GraphGen {
    // constants
    private static final int[] vertexVal = {10, 20, 30, 40, 50};
    private static final int[] edgeVal = {20, 35, 50, 65, 80};
    private static final int numGraphs = 25;

    public static void main(String[] args) {
        int graphCount = 1;
        // interates through the loop so that each vertexVal will be paired with each edgeVal at least once
        for (int i = 0; i < vertexVal.length; i++) {
            int maxV = vertexVal[i];
            int maxE = edgeVal[i];
            // generates 5 graphs for each edgeVal & vertexVal pair (ie. vertexVal = 10 & edgeVal = 20 for one graph and 35 for another and so forth)
            for (int j = 1; j <= 5; j++) {
                Random r = new Random();

                int numV = maxV;
                List<String> v = new ArrayList<>();  // used to store vertices
                Set<Integer> used = new HashSet<>(); // disallows duplicates
                // generates nodes in the form of NodeXX for each vertex pair
                for (int k = 0; k < numV; k++) {
                    int index;
                    do {
                        index = r.nextInt(maxV) + 1;
                    } 
                    while (used.contains(index));
                    used.add(index);
                    String vertex = "Node" + String.format("%02d", index); // formats vertex as NodeXX
                    v.add(vertex);
                }
                int noE = r.nextInt(Math.min(numV * (numV - 1) / 2, maxE)) + 1;
                List<String> edges = new ArrayList<>();
                // loop continues until the number of edges required is larger than the size of the edges array
                while (edges.size() < noE) {
                    String v1 = v.get(r.nextInt(numV));
                    String v2 = v.get(r.nextInt(numV));
                    // checks that source and destination nodes are not the same
                    if (!v1.equals(v2)) {
                        boolean exist = false;
                        // check if the edge already exists between the two vertices
                        for (String e : edges) {
                            StringTokenizer st = new StringTokenizer(e);
                            String eV1 = st.nextToken();
                            String eV2 = st.nextToken();
                            if ((v1.equals(eV1) && v2.equals(eV2)) || (v1.equals(eV2) && v2.equals(eV1))) {
                                exist = true;
                                break;
                            }
                        }
                        if (!exist) {
                            int weight = r.nextInt(10) + 1;
                            edges.add(v1 + " " + v2 + " " + weight);    // add the NodeXX NodeXX cost to the datafile
                        }
                    }
                }
                try {
                    // titles the datafile according to the naming convension
                    String filename = "graph" + graphCount + ".txt";
                    // creates file with the generated file name
                    File outputFile = new File(filename);
                    // writes to the datafile
                    FileWriter writer = new FileWriter(outputFile);
                    // write in all the lines of edges
                    for (String edge : edges) {
                        writer.write(edge.replace("Node", "Node") + "\n");
                    }
                    writer.close();
                    System.out.println("File written to: " + outputFile.getAbsolutePath());
                } catch (IOException e) {
                    e.printStackTrace();
                }
                // increment the graphCount to track the number of graphs(datafiles) already created
                graphCount++;
                // if the graphCount tracker is larger than the predetermined amount of graphs required, break out of the for loop for generation
                if (graphCount > numGraphs) {
                    break;
                }
            }
            // if the graphCount tracker is larger than the predetermined amount of graphs required, break out of the for loop for determining vertex/edge pairs
            if (graphCount > numGraphs) {
                break;
            }
        }
    }
}