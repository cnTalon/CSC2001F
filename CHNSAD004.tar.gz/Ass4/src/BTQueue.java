
/**
 * BTQueue class used for traversals
 * @author Hussein Suleman -> adapted by CHNSAD004
 */
public class BTQueue<dataType>
{
   BTQueueNode<dataType> head;
   BTQueueNode<dataType> tail;

   public BTQueue ()
   {
      head = null;
      tail = null;
   }

   
   /** 
    * Gets next node in the queue
    * @return BinaryTreeNode<dataType>
    */
   public BinaryTreeNode<dataType> getNext ()
   {
      if (head == null)
         return null;
      BTQueueNode<dataType> qnode = head;
      head = head.next;
      if ( head == null )
         tail = null;
      return qnode.node;
   }

   /**
    * Replaces node with new node
    * @param node binary tree node
    */
   public void enQueue ( BinaryTreeNode<dataType> node )
   {
      if (tail == null)
      {
         tail = new BTQueueNode<dataType> (node, null);
         head = tail;
      }
      else
      {
         tail.next = new BTQueueNode<dataType> (node, null);
         tail = tail.next;
      }
   }
}
