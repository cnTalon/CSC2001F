// Assignment 4 Post
// 11 April 2023
// CHNSAD004
// Content: post class created by CHNSAD004 with getters & setters and methods


    /** 
     * Post class is used to create posts and is used in Account class to store a collection of posts
     * A post should have at least a video file, number of likes and a title
     * @author CHNSAD004
     * @param Post creation of a post
     * @return a post with all the inputted details
     */
public class Post implements Comparable<Post>{
    private String title, video, account;
    private int likes;

    /**
     * Creates a Post object
     * @param v video file name
     * @param l number of likes
     * @param t title of the post
     */
    public Post(String v, int l, String t) {
        this.title = t;
        this.video = v;
        this.likes = l;
    }

    
    /** 
     * Gets the title of the post
     * @return post title
     */
    public String getTitle() {
        return title;
    }

    /** 
     * Gets the video file name of the post
     * @return video file name
     */
    public String getVideo() {
        return video;
    }

    /** 
     * Gets the number of likes of the post
     * @return amount of likes on a post
     */
    public int getLikes() {
        return likes;
    }

    /** 
     * Sets the title of the post
     * @param t set title of post
     * @return stores title of post
     */
    public void setTitle(String t) {
        this.title = t;
    }

    /** 
     * Sets the video file name of the post
     * @param v set video file
     * @return stores video file of post
     */
    public void setVideo(String v) {
        this.video = v;
    }

    /** 
     * Sets the number of likes of the post
     * @param l set likes of post
     * @return stores likes of post
     */
    public void setLikes(int l) {
        this.likes = l;
    }

    /** 
     * Converts the post object into a string output
     * @return the data of a post in a nicely formatted manner
     */
    @Override
    public String toString() {
        return "\nTitle: " + title + "\nVideo: " + video + "\nLikes: " + likes;
    }

    /** 
     * Compares an account name with another account
     * @param another another account to compare against
     * @return an integer value for true or false
     */
    public int compareTo(Post another) {
        return account.compareTo(another.account);
    }
}
