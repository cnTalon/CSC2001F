// Hussein's Binary Tree
// 26 March 2017
// Hussein Suleman

/**
 * BTQueueNode class used in the BTQueue class for traversals
 * @author Hussein Suleman -> adapted by CHNSAD004 for use
 */
public class BTQueueNode<dataType>
{
   BinaryTreeNode<dataType> node;
   BTQueueNode<dataType> next;

   /**
    * Create a BTQueue node
    * @param n binary tree node
    * @param nxt next node
    */
   public BTQueueNode ( BinaryTreeNode<dataType> n, BTQueueNode<dataType> nxt )
   {
      node = n;
      next = nxt;
   }
}
