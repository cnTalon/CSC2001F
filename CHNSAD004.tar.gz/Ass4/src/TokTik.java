// Assignment 4
// 11 April 2023
// CHNSAD004
// Content: the TokTik program

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import javax.swing.*;

/**
 * The TokTik program complete with an interface and ability to perform 7 functions that are selectable from an Options Menu.
 * @author CHNSAD004
 */
public class TokTik {
    
    /** 
     * TokTik is the main class we will be using to run the different functions requested.
     * @param args TokTik program
     * @returns TokTik program
     */
    public static void main(String[] args) {
        BinarySearchTree<Account> bst = new BinarySearchTree<>();   //new bst
        boolean flag = true;    //condition for while loop
        while (flag) {
            // selection of option
            String kb = JOptionPane.showInputDialog(null, optionsP(), "TokTik.exe", JOptionPane.PLAIN_MESSAGE);
            try {
                
            int choice = Integer.parseInt(kb);  // convert string to int for happiness
            switch(choice) {
                case 1:
                //1. Find the profile description for a given account
                    try {
                        // receive in user input
                        String name = JOptionPane.showInputDialog(null, "Enter an account name: ", "Find Account Description", JOptionPane.PLAIN_MESSAGE);
                        Account temp = new Account(name, "");   // create temp account to use for attribute matching
                        BinaryTreeNode<Account> tempNode = bst.find(temp);  // create node to store the wanted and found account from bst
                        // checks if node data has a description
                        if (tempNode.data.getDescription() != null) {
                            // outputs the account description
                            JOptionPane.showMessageDialog(null, "Account Description is:" + tempNode.data.getDescription(), "TokTik.exe", JOptionPane.PLAIN_MESSAGE);
                        }
                        else {
                            // warns that account has no description
                            JOptionPane.showMessageDialog(null, "Account doesn't have a description!", "TokTik.exe", 1);
                        }
                    } 
                    // throws exception when account doesnt exist in bst
                    catch (NullPointerException n) {
                        JOptionPane.showMessageDialog(null, "Account doesn't exist!", "Sorry :(", 0);
                        }
                    break;
                case 2:
                //2. List all accounts
                    System.out.println("Existing Accounts:");   // sets a heading
                    bst.inOrder();  // prints out the accounts in alphabetical order
                    // tells user all existing accounts are printed
                    JOptionPane.showMessageDialog(null, "All existing accounts displayed!", "TokTik.exe", 1);

                    break;
                case 3:
                //3. Create an account
                    // prompts user input for acc name
                    String a = JOptionPane.showInputDialog(null, "Enter an account name: ", "Account Creation", JOptionPane.PLAIN_MESSAGE);
                    // checks that input isnt blank/empty & throws warning if it is
                    if (a.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Invalid account name!\nPlease enter a valid account name!", "Sorry :(", 0);
                        break;
                    }
                    else {}
                    // prompts user input for acc description
                    String d = JOptionPane.showInputDialog(null, "Enter a profile description: ", "Account Creation", JOptionPane.PLAIN_MESSAGE);
                    Account acc = new Account(a, d);    // creates the account using user input
                    bst.insert(acc);    // adds the account as a node to the bst
                    // returns user account details
                    JOptionPane.showMessageDialog(null, "Your new account details:\nAccount Name: " + a + "\nYour profile description: " + d, "TokTik.exe", JOptionPane.PLAIN_MESSAGE);
                    break;
                case 4:
                //4. Delete an account
                    // prompts user for account for deletion
                    String deleteAcc = JOptionPane.showInputDialog(null, "Enter an account to delete: ", "Account Deletion", JOptionPane.PLAIN_MESSAGE);
                        // create temp account to use in find method in bst and returns a node or null
                        BinaryTreeNode<Account> dAcc = bst.find(new Account(deleteAcc, ""));
                        // as long as node isnt empty this runs
                        if (dAcc != null) {
                            // prompts confirmation of deletion
                            String ans = JOptionPane.showInputDialog(null, "Are you sure you want to delete " + deleteAcc + "? [Y/N]", "Confirm Deletion", 1);
                            // checks confirmation
                            if (ans.compareTo("Y") == 0) {
                                bst.delete(new Account(deleteAcc, ""));     // deletes account from bst
                                // informs user of deletion success
                                JOptionPane.showMessageDialog(null, deleteAcc +" has been successfully deleted!", "TokTik.exe", 1);
                            }
                            else {
                                // stops deletion if user inputs N
                                JOptionPane.showMessageDialog(null, "Account deletion stopped!", "TokTik.exe", 1);
                            }
                        }
                        else {
                            // warns user that account doesnt exist
                            JOptionPane.showMessageDialog(null, "Account doesn't exist!", "Sorry :(", 0);
                        }
                    break;
                case 5:
                //5. Display all posts for a single account
                    // prompts user for account name
                    String A = JOptionPane.showInputDialog(null, "Enter an account name: ", "Display All Posts of An Account", JOptionPane.PLAIN_MESSAGE);
                    Account disAcc = new Account(A, "");    // creates temp account
                    BinaryTreeNode<Account> tempDis = bst.find(disAcc); // uses temp account to find particular node in bst
                    // check that node is not empty(null)
                    if (tempDis != null) {
                        System.out.println(A + "'s posts:");  // prints out a heading
                        // loops through the array until all posts are printed
                        for (int i = 0; i < tempDis.data.getPosts().size(); i++) {
                            System.out.println(tempDis.data.getPosts().get(i) + "\n");
                        }
                        System.out.println("End of " + A + "'s Posts.");    // tells user it's the end of posts
                        // popup that tells user that all posts are printed
                        JOptionPane.showMessageDialog(null, A + "'s Posts Displayed!", "TokTik.exe", JOptionPane.PLAIN_MESSAGE);
                    }
                    else {
                        // warns user that account has no posts
                        JOptionPane.showMessageDialog(null, "Account has doesn't exist.", "Sorry :(", 0);
                    }
                    break;
                case 6:
                //6. Add a new post for an account
                    // prompts user for account name
                    String currentN = JOptionPane.showInputDialog(null, "Enter an account name: ", "Adding a Post", JOptionPane.PLAIN_MESSAGE);
                    Account addPost = new Account(currentN, "");    // create temp account
                    BinaryTreeNode<Account> tempNode = bst.find(addPost);   // uses temp account to find the account in bst

                    // checks that the account exists (not empty/null)
                    if (tempNode != null) {
                        // prompts user for video file name
                        String v = JOptionPane.showInputDialog(null, "Enter video file: ", "Adding a Post", JOptionPane.PLAIN_MESSAGE);
                        // prompts user for likes on video
                        String likes = JOptionPane.showInputDialog(null, "Enter likes: ", "Adding a Post", JOptionPane.PLAIN_MESSAGE);
                        // prompts user for title
                        String t = JOptionPane.showInputDialog(null, "Enter title ", "Adding a Post", JOptionPane.PLAIN_MESSAGE);
                        // converts string to int to use in post class
                        int l = Integer.parseInt(likes);
                        Post p = new Post(v, l, t); // creates the post
                        tempNode.data.addPost(p); // adds post to array of the account
                        JOptionPane.showMessageDialog(null, "\"" + t + "\"" + " created successfully", "TokTik.exe", JOptionPane.PLAIN_MESSAGE);
                    }
                    else {
                        // warns user that account doesn't exist
                        JOptionPane.showMessageDialog(null, currentN +" doesn't exist.", "Sorry :(", 0);
                    }
                    break;
                case 7:
                //7. Load a file of actions from disk and process this
                    // prompts user for file name
                    String fileName = JOptionPane.showInputDialog(null, "Enter File Name: ", "Load File from Disk", JOptionPane.PLAIN_MESSAGE);
                // checks that file exists
                try {    
                    // reads the whole file
                    Scanner read = new Scanner(new File(fileName));
                    // checks that file still has text
                    while (read.hasNextLine()) {
                        // reads the whole line
                        Scanner readL = new Scanner(read.nextLine());
                        // checks for action (Create/Add)
                        String valid = readL.next();
                        // decides action
                        if (valid.compareTo("Create") == 0) {
                            String accN = readL.next();
                            String desc = readL.nextLine();
                            bst.insert(new Account(accN, desc)); // creates an account & add to bst
                        }
                        else {
                            String aN = readL.next();
                            String video = readL.next();
                            int likes = readL.nextInt();
                            String title = readL.nextLine();
                            Account account = new Account(aN, ""); // create temp account
                            BinaryTreeNode<Account> currentNo = bst.find(account); // use temp account to find account in bst
                            Post p = new Post(video, likes, title); // creates post
                            currentNo.data.addPost(p); //adds post to account's list
                        }
                    }
                    // tells user that file is done loading
                    JOptionPane.showMessageDialog(null, "File has been loaded from disk!", "TokTik.exe", JOptionPane.PLAIN_MESSAGE);
                }
                // warns user that file doesn't exist
                catch (FileNotFoundException e) {
                    JOptionPane.showMessageDialog(null, "Error404: File not found in directory.", "Error404", 0);
                    }
                    break;
                case 8:
                //8. Quit
                    // changes boolean to false to end loop
                    flag = false;
                    // goodbye message popup
                    JOptionPane.showMessageDialog(null, "Bye!", "TokTik.exe", JOptionPane.PLAIN_MESSAGE);
                    break;
            }
            }
            //if the input is not a number or is empty a warning is issued and the menu is repeated 
                catch (NumberFormatException num) {
                JOptionPane.showMessageDialog(null, "Enter a valid number!", "Sorry :(", 0);
            }
        }
    }

    
    /** 
     * Creates a menu with selection choices for the user
     * @return String with menu options
     */
    public static String optionsP() {
        String options = "Choose an action from the menu:\n"
        + "1. Find the profile description for a given account\n"
        + "2. List all accounts\n"
        + "3. Create an account\n"
        + "4. Delete an account\n"
        + "5. Display all posts for a single account\n"
        + "6. Add a new post for an account\n"
        + "7. Load a file of actions from disk and process this\n"
        + "8. Quit\n"
        + "Enter your choice: ";
        return options;
    }
}
