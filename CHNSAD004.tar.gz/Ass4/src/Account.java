// Assignment 4 Account
// 11 April 2023
// CHNSAD004
// Content: account class created by CHNSAD004 with constructors, getters & setters and methods

import java.util.LinkedList;

/**
 * Account class used to create accounts to store as nodes in the BST
 * @author CHNSAD004
 */
public class Account implements Comparable<Account>{
    private String name;
    private String description;
    private LinkedList<Post> posts = new LinkedList<>();

    /**
     * Create an account
     * @param n name string
     * @param d description string
     */
    //constructors
    public Account(String n, String d) {
        this.name = n;
        this.description = d;
    }

    /**
     * Create temp account
     * @param name name
     */
    public Account(String name) {
        this.name = name;
    }

    
    /** 
     * Returns the name of an account
     * @return String
     */
    public String getName() {
        return name;
    }
    
    /** 
     * Returns the description of an account
     * @return account description
     */
    public String getDescription() {
        return description;
    }

    /** 
     * Return the posts of an account
     * @return account posts in a formatted list
     */
    public LinkedList<Post> getPosts() {
        return posts;
    }

    /** 
     * Sets the name of an account
     * @param name set the account name
     * 
     */
    public void setName(String name) {
        this.name = name;
    }

    /** 
     * Sets the decription of an account
     * @param description set desc of an account
     * 
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /** 
     * Sets the posts of an account
     * @param posts set posts of an account
     * 
     */
    public void setPosts(LinkedList<Post> posts) {
        this.posts = posts;
    }

    /** 
     * Adds a post to an account's post list
     * @param post add post to an account
     * 
     */
    public void addPost(Post post) {
        posts.add(post);
    }

    /** 
     * Compares an account via account name
     * @param another another account name to compare against
     * @return returns an integer used in true/false instances
     */
    public int compareTo(Account another) {
        return name.compareTo(another.name);
    }

    /** 
     * Converts account object to a string
     * @return formatted account details
     */
    public String toString() {
        return "Account: " + name + " ~" + description;
    }

    /**
     * 
     * Method to check what kind of poster the account holder is
     * @return returns name of account with/without the tag
     */
    public String checkPop() {
        if (posts.size() >= 5) {
            return this.name = name + "[Reg Poster]";
        }
        else if (posts.size() >= 10) {
            return this.name = name + "[Daily Poster]";
        }
        else if (posts.size() >= 20) {
            return this.name = name + "[Super Poster]";
        }
        else return name;
    }
}
