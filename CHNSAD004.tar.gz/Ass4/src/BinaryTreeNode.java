/**
 * Binary tree node class for use with binary search tree
 * @author Hussein Suleman -> adapted by CHNSAD004
 */
public class BinaryTreeNode<dataType>
{
   dataType data;
   BinaryTreeNode<dataType> left;
   BinaryTreeNode<dataType> right;

   /**
    * Creates a binary tree node
    * @param d datatype
    * @param l binary tree node
    * @param r another binary tree node
    */
   public BinaryTreeNode ( dataType d, BinaryTreeNode<dataType> l, BinaryTreeNode<dataType> r )
   {
      data = d;
      left = l;
      right = r;
   }

   BinaryTreeNode<dataType> getLeft () { return left; }
   BinaryTreeNode<dataType> getRight () { return right; }

   
   /** 
    * @return String
    */
   public String getDescription() {
      return null;
  }
}

